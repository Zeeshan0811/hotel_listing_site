"use strict";
exports.id = 101;
exports.ids = [101];
exports.modules = {

/***/ 4101:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8210);
/* harmony import */ var _connection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7056);
/* harmony import */ var _Image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2815);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__, _Image__WEBPACK_IMPORTED_MODULE_2__]);
([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__, _Image__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const initHotel = (sequelize, Types)=>{
    class Hotel extends sequelize__WEBPACK_IMPORTED_MODULE_0__.Model {
    }
    Hotel.init({
        hotel_id: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        hotel_uri: Types.STRING,
        name: Types.STRING,
        email: Types.STRING,
        phone: Types.STRING,
        phone_2: Types.STRING,
        email: Types.STRING,
        website: Types.STRING,
        about: Types.STRING,
        important_notice: Types.STRING,
        address: Types.STRING,
        address_line_2: Types.STRING,
        city: Types.STRING,
        country: Types.STRING,
        zip: Types.STRING
    }, {
        sequelize,
        modelName: "Hotel",
        tableName: "nso_hotel",
        createdAt: "created_at",
        updatedAt: "updated_at"
    });
    Hotel.hasMany(_Image__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        foreignKey: "reference_id"
    });
    return Hotel;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (initHotel(_connection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2815:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8210);
/* harmony import */ var _connection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7056);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__]);
([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const initImage = (sequelize, Types)=>{
    class Image extends sequelize__WEBPACK_IMPORTED_MODULE_0__.Model {
    }
    Image.init({
        image_id: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        image_type: Types.INTEGER,
        reference_id: Types.INTEGER,
        path: Types.STRING,
        image: Types.STRING,
        title: Types.STRING,
        image_order: Types.INTEGER,
        created_by: Types.INTEGER,
        updated_by: Types.INTEGER
    }, {
        sequelize,
        modelName: "image",
        tableName: "nso_images",
        createdAt: "created_at",
        updatedAt: "updated_at"
    });
    return Image;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (initImage(_connection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;