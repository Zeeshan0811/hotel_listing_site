"use strict";
exports.id = 350;
exports.ids = [350];
exports.modules = {

/***/ 350:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8210);
/* harmony import */ var _connection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7056);
/* harmony import */ var _Category__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9888);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__, _Category__WEBPACK_IMPORTED_MODULE_2__]);
([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__, _Category__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const initAllsetup = (sequelize, Types)=>{
    class Allsetup extends sequelize__WEBPACK_IMPORTED_MODULE_0__.Model {
    }
    Allsetup.init({
        unitId: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        type: Types.STRING,
        title: Types.STRING,
        icon: Types.STRING
    }, {
        sequelize,
        modelName: "Allsetup",
        tableName: "nso_allsetup",
        createdAt: "created_at",
        updatedAt: "updated_at"
    });
    Allsetup.associate = function(models) {
        _Category__WEBPACK_IMPORTED_MODULE_2__/* ["default"].belongsTo */ .Z.belongsTo(models.Allsetup, {
            foreignKey: "type"
        });
    };
    return Allsetup;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (initAllsetup(_connection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9888:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8210);
/* harmony import */ var _connection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7056);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__]);
([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const initCategory = (sequelize, Types)=>{
    class Category extends sequelize__WEBPACK_IMPORTED_MODULE_0__.Model {
    }
    Category.init({
        cat_id: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        cat_title: Types.STRING,
        cat_note: Types.STRING
    }, {
        sequelize,
        modelName: "Category",
        tableName: "nso_cateogory",
        createdAt: "created_at"
    });
    Category.associate = function(models) {
        Category.hasOne(models.role, {
            foreignKey: "cat_id",
            sourceKey: "type"
        });
    };
    return Category;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (initCategory(_connection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;