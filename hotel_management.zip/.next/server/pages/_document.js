"use strict";
(() => {
var exports = {};
exports.id = 660;
exports.ids = [660];
exports.modules = {

/***/ 1814:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Document)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/document.js
var next_document = __webpack_require__(6859);
;// CONCATENATED MODULE: ./components/HeadFiles.js

function HeadFiles() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                href: "https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900&display=optional",
                rel: "stylesheet",
                type: "text/css"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                href: "/assets/admin/css/icons/icomoon/styles.min.css",
                rel: "stylesheet",
                type: "text/css"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                href: "/assets/admin/css/bootstrap.min.css",
                rel: "stylesheet",
                type: "text/css"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                href: "/assets/admin/css/bootstrap_limitless.min.css",
                rel: "stylesheet",
                type: "text/css"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                href: "/assets/admin/css/layout.min.css",
                rel: "stylesheet",
                type: "text/css"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                href: "/assets/admin/css/components.min.css",
                rel: "stylesheet",
                type: "text/css"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                href: "/assets/admin/css/sweetalert2.min.css",
                rel: "stylesheet",
                type: "text/css"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                href: "/assets/admin/css/colors.min.css",
                rel: "stylesheet",
                type: "text/css"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                href: "/assets/admin/css/custom.css",
                rel: "stylesheet",
                type: "text/css"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/main/jquery.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/main/bootstrap.bundle.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/loaders/blockui.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/main/aes.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/visualization/d3/d3.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/visualization/d3/d3_tooltip.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/forms/styling/switchery.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/forms/selects/bootstrap_multiselect.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/extensions/jquery_ui/interactions.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/forms/selects/select2.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/forms/styling/uniform.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/ui/moment/moment.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/pickers/daterangepicker.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/notifications/bootbox.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/datatables/datatables.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/pages/datatables_basic.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/pages/datatables_advanced.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/datatables/extensions/jszip/jszip.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/datatables/extensions/pdfmake/pdfmake.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/datatables/extensions/pdfmake/vfs_fonts.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/datatables/extensions/buttons.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/datatables/extensions/select.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/loaders/blockui.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/media/fancybox.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/uploaders/dropzone.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/forms/styling/uniform.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/pickers/daterangepicker.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/pickers/anytime.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/pickers/pickadate/picker.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/pickers/pickadate/picker.date.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/pickers/pickadate/picker.time.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/pickers/pickadate/legacy.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/notifications/noty.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/pages/extra_noty.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/app.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/pages/dashboard.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/pages/components_modals.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/pages/form_layouts.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/pages/form_select2.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/pages/picker_date.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/pages/gallery_library.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/pages/uploader_dropzone.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/pages/datatables_extension_buttons_html5.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/datatables/extensions/datatables_extension_buttons_print.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/plugins/notifications/sweet_alert.min.js"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("script", {
                defer: true,
                src: "/assets/admin/js/custom.js"
            })
        ]
    });
};

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/Header.js





function Header() {
    const handleGetuser = async (e)=>{
        e.preventDefault();
        console.log("Account Settings");
        const user = await external_axios_default().get("api/user");
        console.log(user);
    };
    const handleLogout = async (e)=>{
        e.stopPropagation();
        console.log("Log Out Now ");
    };
    const logo = `/upload/logo/logo.png`;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "navbar navbar-expand-md navbar-dark",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "navbar-brand",
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        className: "d-inline-block",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: logo,
                            alt: "",
                            // layout='fill'
                            width: "90px",
                            height: "100px",
                            loading: "lazy"
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "d-md-none",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "navbar-toggler",
                        type: "button",
                        "data-toggle": "collapse",
                        "data-target": "#navbar-mobile",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "icon-tree5"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "navbar-toggler sidebar-mobile-main-toggle",
                        type: "button",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "icon-paragraph-justify3"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "collapse navbar-collapse",
                id: "navbar-mobile",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        className: "navbar-nav",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav-item",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "#",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    className: "navbar-nav-link sidebar-control sidebar-main-toggle d-none d-md-block",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "icon-paragraph-justify3"
                                    })
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "badge bg-success ml-md-3 mr-md-auto",
                        children: "Online"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        className: "navbar-nav",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                            className: "nav-item dropdown dropdown-user",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "#",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        className: "navbar-nav-link d-flex align-items-center dropdown-toggle",
                                        "data-toggle": "dropdown",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                src: "",
                                                className: "rounded-circle mr-2",
                                                height: "34",
                                                width: "34",
                                                alt: ""
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Admin"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "dropdown-menu dropdown-menu-right",
                                    children: [
                                        ".",
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "#",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                onClick: (e)=>handleGetuser(e),
                                                className: "dropdown-item",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icon-cog5"
                                                    }),
                                                    "Account settings"
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "#",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                className: "dropdown-item",
                                                onClick: (e)=>{
                                                    e.preventDefault();
                                                    console.log("asdsad");
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icon-switch2"
                                                    }),
                                                    "Logout"
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/Sidebar.js



function Sidebar() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "sidebar sidebar-dark sidebar-main sidebar-expand-md no-print",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "sidebar-mobile-toggler text-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "#",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "sidebar-mobile-main-toggle",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "icon-arrow-left8"
                            })
                        })
                    }),
                    "Navigation",
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "#",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                            className: "sidebar-mobile-expand",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "icon-screen-full"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                    className: "icon-screen-normal"
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "sidebar-content",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "card card-sidebar-mobile",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "nav nav-sidebar",
                        "data-nav-type": "accordion",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "nav-item",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                        className: "nav-link",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "icon-home4"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "Dashboard"
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "nav-item nav-item-submenu",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            className: "nav-link",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "icon-stack"
                                                }),
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Category"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "nav nav-group-sub",
                                        "data-submenu-title": "Starter kit",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/admin/category/add",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "nav-link",
                                                        children: "Add New"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/admin/category/list",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "nav-link",
                                                        children: "Category List"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "nav-item nav-item-submenu",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            className: "nav-link",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "icon-stack"
                                                }),
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Services"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "nav nav-group-sub",
                                        "data-submenu-title": "Starter kit",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/admin/services/add",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "nav-link",
                                                        children: "Add New"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/admin/services/list",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "nav-link",
                                                        children: "Services List"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "nav-item nav-item-submenu",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            className: "nav-link",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "icon-stack"
                                                }),
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Hotel"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "nav nav-group-sub",
                                        "data-submenu-title": "Starter kit",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/admin/hotel/add",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "nav-link",
                                                        children: "Add New"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/admin/hotel/list",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "nav-link",
                                                        children: "Hotel List"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "nav-item nav-item-submenu",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            className: "nav-link",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "icon-stack"
                                                }),
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Room"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "nav nav-group-sub",
                                        "data-submenu-title": "Starter kit",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/admin/room/add",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "nav-link",
                                                        children: "Add New"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/admin/room/list",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "nav-link",
                                                        children: "Room List"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "nav-item nav-item-submenu",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            className: "nav-link",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "icon-stack"
                                                }),
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "User"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "nav nav-group-sub",
                                        "data-submenu-title": "Starter kit",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/admin/user/add",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "nav-link",
                                                        children: "Add New"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/admin/user/list",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "nav-link",
                                                        children: "User List"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                className: "nav-item nav-item-submenu",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "#",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            className: "nav-link",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                    className: "icon-cog3"
                                                }),
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Settings"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        className: "nav nav-group-sub",
                                        "data-submenu-title": "Starter kit",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/admin/setting/company",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "nav-link",
                                                        title: "Company Setting",
                                                        children: "Company Setting"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/admin/setting/password",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "nav-link",
                                                        title: "Change Password",
                                                        children: "Change Password"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                className: "nav-item",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                    href: "/admin/setting/user",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        className: "nav-link",
                                                        title: "User Setting",
                                                        children: "User Setting"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/Footer.js

function Footer() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "navbar navbar-expand-lg navbar-light",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-center d-lg-none w-100",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                    type: "button",
                    className: "navbar-toggler dropdown-toggle",
                    "data-toggle": "collapse",
                    "data-target": "#navbar-footer",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "icon-unfold mr-2"
                        }),
                        "Footer"
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "navbar-collapse collapse",
                id: "navbar-footer",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "navbar-text",
                        children: [
                            "\xa9 ",
                            new Date().getFullYear()
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        className: "navbar-nav ml-lg-auto",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav-item",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: "#",
                                className: "navbar-nav-link",
                                target: "_blank",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "icon-lifebuoy mr-2"
                                    }),
                                    " Support"
                                ]
                            })
                        })
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: external "jsonwebtoken"
const external_jsonwebtoken_namespaceObject = require("jsonwebtoken");
;// CONCATENATED MODULE: ./pages/_document.js







function Document() {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(next_document.Html, {
        lang: "en",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(next_document.Head, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(HeadFiles, {})
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("body", {
                className: "home",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Header, {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "page-content",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Sidebar, {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "content-wrapper",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(next_document.Main, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx(next_document.NextScript, {}),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Footer, {})
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 4140:
/***/ ((module) => {

module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 9716:
/***/ ((module) => {

module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 6368:
/***/ ((module) => {

module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 6724:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8743:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [910,664,675,859], () => (__webpack_exec__(1814)));
module.exports = __webpack_exports__;

})();