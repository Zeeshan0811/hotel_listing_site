"use strict";
(() => {
var exports = {};
exports.id = 908;
exports.ids = [908];
exports.modules = {

/***/ 4802:
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ 5612:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Handler)
});

;// CONCATENATED MODULE: external "jsonwebtoken"
const external_jsonwebtoken_namespaceObject = require("jsonwebtoken");
// EXTERNAL MODULE: external "cookie"
var external_cookie_ = __webpack_require__(4802);
;// CONCATENATED MODULE: ./pages/api/auth/login.js


const secret = process.env.SECRET_AUTH_KEY;
async function Handler(req, res) {
    const { username , password  } = req.body;
    // console.log(secret);
    // Check in the database
    // if a user with this username
    // and password exists
    if (username === "Admin" && password === "Admin") {
        const token = (0,external_jsonwebtoken_namespaceObject.sign)({
            exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 30,
            username: username
        }, secret);
        const serialised = (0,external_cookie_.serialize)("OursiteJWT", token, {
            httponly: true,
            secure: "production" != "development",
            sameSite: "strict",
            maxAge: 60 * 60 * 24 * 30,
            path: "/"
        });
        res.setHeader("Set-Cookie", serialised);
        res.status(200).json({
            message: "Success!"
        });
    } else {
        res.json({
            message: "Invalid Credentials"
        });
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5612));
module.exports = __webpack_exports__;

})();