"use strict";
(() => {
var exports = {};
exports.id = 415;
exports.ids = [415];
exports.modules = {

/***/ 4802:
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ 4766:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Handler)
/* harmony export */ });
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4802);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cookie__WEBPACK_IMPORTED_MODULE_0__);

async function Handler(req, res) {
    const { cookies  } = req;
    const jwt = cookies.OursiteJWT;
    if (!jwt) {
        return res.json({
            message: "Bro you are already not logged in..."
        });
    } else {
        const serialised = (0,cookie__WEBPACK_IMPORTED_MODULE_0__.serialize)("OursiteJWT", null, {
            httpOnly: true,
            secure: "production" !== "development",
            sameSite: "strict",
            maxAge: -1,
            path: "/"
        });
        res.setHeader("Set-Cookie", serialised);
        res.status(200).json({
            message: "Successfully logged out!"
        });
        res.end();
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(4766));
module.exports = __webpack_exports__;

})();