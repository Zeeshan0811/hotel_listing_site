"use strict";
(() => {
var exports = {};
exports.id = 730;
exports.ids = [730];
exports.modules = {

/***/ 7773:
/***/ ((module) => {

module.exports = require("winston");

/***/ }),

/***/ 767:
/***/ ((module) => {

module.exports = require("winston-daily-rotate-file");

/***/ }),

/***/ 8210:
/***/ ((module) => {

module.exports = import("sequelize");;

/***/ }),

/***/ 4618:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8210);
/* harmony import */ var _connection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7056);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__]);
([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const initRoom = (sequelize, Types)=>{
    class Room extends sequelize__WEBPACK_IMPORTED_MODULE_0__.Model {
    }
    Room.init({
        room_id: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        uri: Types.STRING,
        title: Types.STRING,
        short_descritpion: Types.STRING,
        description: Types.STRING,
        facilities: Types.STRING,
        views: Types.STRING,
        breakfast: Types.STRING,
        services: Types.STRING,
        guests: Types.STRING,
        beds: Types.STRING,
        created_by: Types.INTEGER,
        Updated_by: Types.INTEGER
    }, {
        sequelize,
        modelName: "Room",
        tableName: "nso_room",
        createdAt: "created_at",
        updatedAt: "updated_at"
    });
    return Room;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (initRoom(_connection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2170:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8210);
/* harmony import */ var _connection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7056);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__]);
([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const initUser = (sequelize, Types)=>{
    class User extends sequelize__WEBPACK_IMPORTED_MODULE_0__.Model {
    }
    User.init({
        userId: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        type: Types.INTEGER,
        firstName: Types.STRING,
        lastName: Types.STRING,
        email: Types.STRING,
        phone: Types.STRING,
        address: Types.STRING,
        address_line_2: Types.STRING,
        city: Types.STRING,
        country: Types.STRING,
        zip: Types.STRING
    }, {
        sequelize,
        modelName: "User",
        tableName: "nso_user",
        createdAt: "created_at",
        updatedAt: "updated_at"
    });
    return User;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (initUser(_connection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7287:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Handler)
/* harmony export */ });
/* harmony import */ var _services_logger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1188);
/* harmony import */ var _database_models_Allsetup__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(350);
/* harmony import */ var _database_models_Hotel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4101);
/* harmony import */ var _database_models_Room__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4618);
/* harmony import */ var _database_models_User__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2170);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_database_models_Allsetup__WEBPACK_IMPORTED_MODULE_1__, _database_models_Hotel__WEBPACK_IMPORTED_MODULE_2__, _database_models_Room__WEBPACK_IMPORTED_MODULE_3__, _database_models_User__WEBPACK_IMPORTED_MODULE_4__]);
([_database_models_Allsetup__WEBPACK_IMPORTED_MODULE_1__, _database_models_Hotel__WEBPACK_IMPORTED_MODULE_2__, _database_models_Room__WEBPACK_IMPORTED_MODULE_3__, _database_models_User__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





async function Handler(req, res) {
    const { slug  } = req.query;
    const type = slug[0];
    const id = slug[1];
    let row = null;
    let modal = null;
    let where_clue = null;
    let unitId = "";
    if (req.method !== "DELETE") {
        res.status(405).send({
            message: "Only DELETE requests are allowed"
        });
        return;
    }
    switch(type){
        case "allsetup":
            modal = _database_models_Allsetup__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z;
            where_clue = {
                "unitId": id
            };
            break;
        case "hotel":
            modal = _database_models_Hotel__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z;
            where_clue = {
                "hotel_id": id
            };
            break;
        case "room":
            modal = _database_models_Room__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z;
            where_clue = {
                "room_id": id
            };
            break;
        case "user":
            modal = _database_models_User__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z;
            where_clue = {
                "userId": id
            };
            break;
        default:
            break;
    }
    try {
        row = await modal.findOne({
            where: where_clue
        });
    } catch (e) {
        _services_logger__WEBPACK_IMPORTED_MODULE_0__/* ["default"].error */ .Z.error(e.stack);
        res.status(400).json({
            error_code: "delete_error",
            message: e.message
        });
    }
    if (row) {
        await row.destroy(); // deletes the row
        res.status(200).json({
            success: "Data has deleted succefully."
        });
    } else {
        res.status(404).json({
            "message": "Data is not found!"
        });
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [56,188,101,350], () => (__webpack_exec__(7287)));
module.exports = __webpack_exports__;

})();