"use strict";
(() => {
var exports = {};
exports.id = 902;
exports.ids = [902];
exports.modules = {

/***/ 8210:
/***/ ((module) => {

module.exports = import("sequelize");;

/***/ }),

/***/ 4618:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8210);
/* harmony import */ var _connection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7056);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__]);
([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const initRoom = (sequelize, Types)=>{
    class Room extends sequelize__WEBPACK_IMPORTED_MODULE_0__.Model {
    }
    Room.init({
        room_id: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        uri: Types.STRING,
        title: Types.STRING,
        short_descritpion: Types.STRING,
        description: Types.STRING,
        facilities: Types.STRING,
        views: Types.STRING,
        breakfast: Types.STRING,
        services: Types.STRING,
        guests: Types.STRING,
        beds: Types.STRING,
        created_by: Types.INTEGER,
        Updated_by: Types.INTEGER
    }, {
        sequelize,
        modelName: "Room",
        tableName: "nso_room",
        createdAt: "created_at",
        updatedAt: "updated_at"
    });
    return Room;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (initRoom(_connection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 853:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Handler)
/* harmony export */ });
/* harmony import */ var _database_models_Room__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4618);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_database_models_Room__WEBPACK_IMPORTED_MODULE_0__]);
_database_models_Room__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function Handler(req, res) {
    const { slug  } = req.query;
    const hotel_uri = slug[0];
    const request_type = slug[1];
    // Get Room List
    if (request_type == "rooms") {
        const rooms = await _database_models_Room__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findAll */ .Z.findAll({
            // where: { hotel_id: hotel_id },
            attributes: {
                exclude: [
                    "created_by",
                    "updated_by",
                    "created_at",
                    "updated_at"
                ]
            },
            limit: 100
        });
        if (rooms === null) {
            res.status(404).json({
                "message": "No Room Found!"
            });
        } else {
            res.status(200).json(rooms);
        }
    }
    // Single Room 
    if (request_type == "room") {
        const room_uri = slug[2];
        const room = await _database_models_Room__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findOne */ .Z.findOne({
            where: {
                uri: room_uri
            },
            attributes: {
                exclude: [
                    "created_by",
                    "updated_by",
                    "created_at",
                    "updated_at"
                ]
            }
        });
        if (room === null) {
            res.status(404).json({
                "message": "No Room Found!"
            });
        } else {
            res.status(200).json(room);
        }
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [56], () => (__webpack_exec__(853)));
module.exports = __webpack_exports__;

})();