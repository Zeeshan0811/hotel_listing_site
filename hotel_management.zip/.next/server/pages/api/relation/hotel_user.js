"use strict";
(() => {
var exports = {};
exports.id = 691;
exports.ids = [691];
exports.modules = {

/***/ 8210:
/***/ ((module) => {

module.exports = import("sequelize");;

/***/ }),

/***/ 7967:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8210);
/* harmony import */ var _connection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7056);
/* harmony import */ var _User__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2170);
/* harmony import */ var _Hotel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4101);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__, _User__WEBPACK_IMPORTED_MODULE_2__, _Hotel__WEBPACK_IMPORTED_MODULE_3__]);
([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__, _User__WEBPACK_IMPORTED_MODULE_2__, _Hotel__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const initHotelUserRel = (sequelize, Types)=>{
    class HotelUserRel extends sequelize__WEBPACK_IMPORTED_MODULE_0__.Model {
    }
    HotelUserRel.init({
        rel_id: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        rel_type: Types.INTEGER,
        hotel_id: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.INTEGER,
            references: {
                model: _Hotel__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
                key: "hotel_id"
            }
        },
        user_id: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.INTEGER,
            references: {
                model: _User__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
                key: "userId"
            }
        }
    }, {
        sequelize,
        modelName: "HotelUserRel",
        tableName: "nso_hotel_user_rel",
        createdAt: "created_at",
        updatedAt: "updated_at"
    });
    HotelUserRel.belongsTo(_User__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        foreignKey: "user_id"
    });
    HotelUserRel.belongsTo(_Hotel__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        foreignKey: "hotel_id"
    });
    return HotelUserRel;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (initHotelUserRel(_connection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2170:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8210);
/* harmony import */ var _connection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7056);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__]);
([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const initUser = (sequelize, Types)=>{
    class User extends sequelize__WEBPACK_IMPORTED_MODULE_0__.Model {
    }
    User.init({
        userId: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        type: Types.INTEGER,
        firstName: Types.STRING,
        lastName: Types.STRING,
        email: Types.STRING,
        phone: Types.STRING,
        address: Types.STRING,
        address_line_2: Types.STRING,
        city: Types.STRING,
        country: Types.STRING,
        zip: Types.STRING
    }, {
        sequelize,
        modelName: "User",
        tableName: "nso_user",
        createdAt: "created_at",
        updatedAt: "updated_at"
    });
    return User;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (initUser(_connection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2714:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Handler)
/* harmony export */ });
/* harmony import */ var _database_models_HotelUserRel__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7967);
/* harmony import */ var _database_models_User__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2170);
/* harmony import */ var _database_models_Hotel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4101);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_database_models_HotelUserRel__WEBPACK_IMPORTED_MODULE_0__, _database_models_User__WEBPACK_IMPORTED_MODULE_1__, _database_models_Hotel__WEBPACK_IMPORTED_MODULE_2__]);
([_database_models_HotelUserRel__WEBPACK_IMPORTED_MODULE_0__, _database_models_User__WEBPACK_IMPORTED_MODULE_1__, _database_models_Hotel__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



async function Handler(req, res) {
    const { rel_type , hotel_id , user_id  } = req.body;
    let rel = null;
    if (req.method == "GET") {
        const rel_id = req.body.rel_id;
        if (rel_id) {
            // Get Single Relation
            rel = await _database_models_HotelUserRel__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findOne */ .Z.findOne({
                where: {
                    rel_id
                },
                attributes: {
                    exclude: [
                        "created_by",
                        "updated_by",
                        "created_at",
                        "updated_at"
                    ]
                },
                limit: 100,
                include: [
                    {
                        model: _database_models_User__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z,
                        attributes: {
                            exclude: [
                                "created_at",
                                "updated_at"
                            ]
                        }
                    },
                    {
                        model: _database_models_Hotel__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
                        attributes: {
                            exclude: [
                                "created_by",
                                "updated_by",
                                "created_at",
                                "updated_at"
                            ]
                        }
                    }
                ]
            });
        } else {
            // Get Relation List
            rel = await _database_models_HotelUserRel__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findAll */ .Z.findAll({
                attributes: {
                    exclude: [
                        "created_by",
                        "updated_by",
                        "created_at",
                        "updated_at"
                    ]
                },
                limit: 100,
                include: [
                    {
                        model: _database_models_User__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z,
                        attributes: {
                            exclude: [
                                "created_at",
                                "updated_at"
                            ]
                        }
                    },
                    {
                        model: _database_models_Hotel__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
                        attributes: {
                            exclude: [
                                "created_by",
                                "updated_by",
                                "created_at",
                                "updated_at"
                            ]
                        }
                    }
                ]
            });
        }
        res.status(200).json({
            rel
        });
    }
    // Create New Room
    if (req.method == "POST") {
        await _database_models_HotelUserRel__WEBPACK_IMPORTED_MODULE_0__/* ["default"].create */ .Z.create({
            rel_type,
            hotel_id,
            user_id
        }).then(function(rel) {
            if (rel) {
                res.status(200).send(rel);
            } else {
                res.status(400).send("Error in insert new record");
            }
        });
    }
    // Update New Room
    if (req.method == "PUT") {
        rel = await _database_models_HotelUserRel__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findOne */ .Z.findOne({
            where: {
                rel_id: req.body.rel_id
            },
            attributes: {
                exclude: [
                    "created_by",
                    "updated_by",
                    "created_at",
                    "updated_at"
                ]
            }
        });
        if (rel) {
            rel_type ? rel.rel_type = rel_type : 0;
            hotel_id ? rel.hotel_id = hotel_id : 0;
            user_id ? rel.user_id = user_id : 0;
            room.save();
            res.send(rel);
        } else {
            res.status(400).send("Error in updating new record");
        }
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [56,101], () => (__webpack_exec__(2714)));
module.exports = __webpack_exports__;

})();