"use strict";
(() => {
var exports = {};
exports.id = 11;
exports.ids = [11];
exports.modules = {

/***/ 7773:
/***/ ((module) => {

module.exports = require("winston");

/***/ }),

/***/ 767:
/***/ ((module) => {

module.exports = require("winston-daily-rotate-file");

/***/ }),

/***/ 8210:
/***/ ((module) => {

module.exports = import("sequelize");;

/***/ }),

/***/ 69:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Handler)
/* harmony export */ });
/* harmony import */ var _database_models_Allsetup__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(350);
/* harmony import */ var _services_logger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1188);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_database_models_Allsetup__WEBPACK_IMPORTED_MODULE_0__]);
_database_models_Allsetup__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


async function Handler(req, res) {
    try {
        const allsetup = await _database_models_Allsetup__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findAll */ .Z.findAll({
            attributes: [
                "type",
                "title",
                "icon"
            ],
            limit: 100
        });
        res.status(200).json(allsetup);
    } catch (e) {
        _services_logger__WEBPACK_IMPORTED_MODULE_1__/* ["default"].error */ .Z.error(e.stack);
        res.status(400).json({
            error_code: "get_allsetup",
            message: e.message
        });
    }
}; // export default function handler(req, res) {
 //     res.status(200).json({ name: 'John Doe' })
 // }

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [56,188,350], () => (__webpack_exec__(69)));
module.exports = __webpack_exports__;

})();