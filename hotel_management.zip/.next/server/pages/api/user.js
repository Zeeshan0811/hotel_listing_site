"use strict";
(() => {
var exports = {};
exports.id = 541;
exports.ids = [541];
exports.modules = {

/***/ 7773:
/***/ ((module) => {

module.exports = require("winston");

/***/ }),

/***/ 767:
/***/ ((module) => {

module.exports = require("winston-daily-rotate-file");

/***/ }),

/***/ 8210:
/***/ ((module) => {

module.exports = import("sequelize");;

/***/ }),

/***/ 2170:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var sequelize__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8210);
/* harmony import */ var _connection__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7056);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__]);
([sequelize__WEBPACK_IMPORTED_MODULE_0__, _connection__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const initUser = (sequelize, Types)=>{
    class User extends sequelize__WEBPACK_IMPORTED_MODULE_0__.Model {
    }
    User.init({
        userId: {
            type: sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true
        },
        type: Types.INTEGER,
        firstName: Types.STRING,
        lastName: Types.STRING,
        email: Types.STRING,
        phone: Types.STRING,
        address: Types.STRING,
        address_line_2: Types.STRING,
        city: Types.STRING,
        country: Types.STRING,
        zip: Types.STRING
    }, {
        sequelize,
        modelName: "User",
        tableName: "nso_user",
        createdAt: "created_at",
        updatedAt: "updated_at"
    });
    return User;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (initUser(_connection__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, sequelize__WEBPACK_IMPORTED_MODULE_0__.DataTypes));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2512:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Handler)
/* harmony export */ });
/* harmony import */ var _database_models_User__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2170);
/* harmony import */ var _services_logger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1188);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_database_models_User__WEBPACK_IMPORTED_MODULE_0__]);
_database_models_User__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


async function Handler(req, res) {
    const { userId  } = req.body;
    try {
        // console.log(userId);
        const user = await _database_models_User__WEBPACK_IMPORTED_MODULE_0__/* ["default"].findOne */ .Z.findOne({
            where: {
                userId: userId
            },
            attributes: {
                exclude: [
                    "created_by",
                    "updated_by",
                    "created_at",
                    "updated_at"
                ]
            }
        });
        if (user === null) {
            res.status(404).json({
                "message": "User is not found!"
            });
        } else {
            res.status(200).json(user);
        }
    } catch (e) {
        _services_logger__WEBPACK_IMPORTED_MODULE_1__/* ["default"].error */ .Z.error(e.stack);
        res.status(400).json({
            error_code: "get_user",
            message: e.message
        });
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [56,188], () => (__webpack_exec__(2512)));
module.exports = __webpack_exports__;

})();